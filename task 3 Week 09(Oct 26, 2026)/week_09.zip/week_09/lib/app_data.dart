class CourseItem {
  final String code;
  final String title;
  final String instructor;
  final String creditHours;
  final double progress;

  CourseItem({
    required this.code,
    required this.title,
    required this.instructor,
    required this.creditHours,
    this.progress = 0.85,
  });
}

class StudentItem {
  final String name;
  final String email;
  final List<CourseItem> registeredCourses;
  final List<CourseItem> pendingCourses;

  StudentItem({
    required this.name,
    required this.email,
    List<CourseItem>? registeredCourses,
    List<CourseItem>? pendingCourses,
  })  : registeredCourses = registeredCourses ?? [],
        pendingCourses = pendingCourses ?? [];
}

class AppData {
  static final AppData _instance = AppData._internal();
  factory AppData() => _instance;
  AppData._internal();

  final List<CourseItem> globalCourses = [
    CourseItem(code: 'CS-411', title: 'Mobile Application Development', instructor: 'Dr. Ahmed Khan', creditHours: '3 Cr. Hrs', progress: 0.90),
    CourseItem(code: 'CS-412', title: 'Artificial Intelligence', instructor: 'Prof. Sarah Malik', creditHours: '3 Cr. Hrs', progress: 0.80),
    CourseItem(code: 'SE-302', title: 'Software Engineering II', instructor: 'Dr. Tariq Mahmood', creditHours: '3 Cr. Hrs', progress: 0.95),
    CourseItem(code: 'CS-301', title: 'Data Structures & Algorithms', instructor: 'Dr. Kamran Iqbal', creditHours: '4 Cr. Hrs', progress: 0.88),
    CourseItem(code: 'CS-305', title: 'Operating Systems', instructor: 'Dr. Farooq Azam', creditHours: '3 Cr. Hrs', progress: 0.75),
    CourseItem(code: 'CS-310', title: 'Database Systems', instructor: 'Prof. Asma Jabeen', creditHours: '3 Cr. Hrs', progress: 0.92),
    CourseItem(code: 'SE-405', title: 'Web Engineering', instructor: 'Dr. Bilal Shafi', creditHours: '3 Cr. Hrs', progress: 0.85),
  ];

  final List<StudentItem> students = [
    StudentItem(
      name: 'Sibghatallah',
      email: 'user@gmail.com',
      registeredCourses: [
        CourseItem(code: 'CS-411', title: 'Mobile Application Development', instructor: 'Dr. Ahmed Khan', creditHours: '3 Cr. Hrs', progress: 0.90),
        CourseItem(code: 'CS-301', title: 'Data Structures & Algorithms', instructor: 'Dr. Kamran Iqbal', creditHours: '4 Cr. Hrs', progress: 0.88),
      ],
      pendingCourses: [], // Starts empty so requests only appear when student registers
    ),
    StudentItem(
      name: 'Fatima Noor',
      email: 'fatima.noor@riphah.edu.pk',
      registeredCourses: [
        CourseItem(code: 'SE-302', title: 'Software Engineering II', instructor: 'Dr. Tariq Mahmood', creditHours: '3 Cr. Hrs', progress: 0.95),
      ],
      pendingCourses: [],
    ),
  ];

  StudentItem get currentStudent => students.first;

  void addGlobalCourse(String code, String title, String instructor, String creditHours) {
    globalCourses.add(CourseItem(code: code, title: title, instructor: instructor, creditHours: creditHours, progress: 0.75));
  }

  void removeGlobalCourse(String code) {
    globalCourses.removeWhere((c) => c.code == code);
  }

  void addStudent(String name, String email) {
    students.add(StudentItem(name: name, email: email));
  }

  void dropCourseForStudent(StudentItem student, CourseItem course) {
    student.registeredCourses.removeWhere((c) => c.code == course.code);
  }

  void registerCourseForStudent(StudentItem student, CourseItem course) {
    if (!student.registeredCourses.any((c) => c.code == course.code) &&
        !student.pendingCourses.any((c) => c.code == course.code)) {
      student.pendingCourses.add(course);
    }
  }

  void approveCourse(StudentItem student, CourseItem course) {
    student.pendingCourses.removeWhere((c) => c.code == course.code);
    if (!student.registeredCourses.any((c) => c.code == course.code)) {
      student.registeredCourses.add(course);
    }
  }

  void rejectCourse(StudentItem student, CourseItem course) {
    student.pendingCourses.removeWhere((c) => c.code == course.code);
  }
}
