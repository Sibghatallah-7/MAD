import 'package:flutter/material.dart';
import 'user_courses_page.dart';
import 'admin_dashboard_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController(text: 'user@gmail.com');
  final TextEditingController _passwordController = TextEditingController(text: 'user123');
  String _selectedRole = 'User';

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _fillUserCredentials() {
    setState(() {
      _selectedRole = 'User';
      _emailController.text = 'user@gmail.com';
      _passwordController.text = 'user123';
    });
  }

  void _fillAdminCredentials() {
    setState(() {
      _selectedRole = 'Admin';
      _emailController.text = 'admin@gmail.com';
      _passwordController.text = 'admin123';
    });
  }

  void _login() {
    final email = _emailController.text.trim().toLowerCase();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.error_outline, color: Colors.white),
              SizedBox(width: 10),
              Expanded(
                child: Text('Please enter both Email and Password.'),
              ),
            ],
          ),
          backgroundColor: Colors.red.shade700,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          duration: const Duration(seconds: 3),
        ),
      );
      return;
    }

    if (_selectedRole == 'Admin' || email == 'admin@gmail.com') {
      if (email == 'admin@gmail.com' && password == 'admin123') {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const AdminDashboardPage(),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(
              children: [
                Icon(Icons.gpp_bad_outlined, color: Colors.white),
                SizedBox(width: 10),
                Expanded(
                  child: Text('Invalid Admin Credentials! Use: admin@gmail.com / admin123'),
                ),
              ],
            ),
            backgroundColor: Colors.red.shade700,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      }
    } else {
      if ((email == 'user@gmail.com' || email == 'sibghatallah@gmail.com') &&
          (password == 'user123' || password == 'User@1234')) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const UserCoursesPage(),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(
              children: [
                Icon(Icons.gpp_bad_outlined, color: Colors.white),
                SizedBox(width: 10),
                Expanded(
                  child: Text('Invalid User Credentials! Use: user@gmail.com / user123'),
                ),
              ],
            ),
            backgroundColor: Colors.red.shade700,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1E88E5),
              Color(0xFF1565C0),
              Color(0xFF0D47A1),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 20.0),
              child: Card(
                elevation: 8,
                shadowColor: Colors.black26,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(28.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: const BoxDecoration(
                          color: Color(0xFFE3F2FD),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _selectedRole == 'Admin' ? Icons.admin_panel_settings_rounded : Icons.school_rounded,
                          size: 48,
                          color: const Color(0xFF1565C0),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        _selectedRole == 'Admin' ? 'Admin Portal Login' : 'Student Portal Login',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0D47A1),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ChoiceChip(
                            label: const Text('Student User'),
                            selected: _selectedRole == 'User',
                            selectedColor: const Color(0xFF1565C0),
                            labelStyle: TextStyle(
                              color: _selectedRole == 'User' ? Colors.white : const Color(0xFF1565C0),
                              fontWeight: FontWeight.bold,
                            ),
                            onSelected: (selected) {
                              if (selected) _fillUserCredentials();
                            },
                          ),
                          const SizedBox(width: 12),
                          ChoiceChip(
                            label: const Text('Admin'),
                            selected: _selectedRole == 'Admin',
                            selectedColor: const Color(0xFF1565C0),
                            labelStyle: TextStyle(
                              color: _selectedRole == 'Admin' ? Colors.white : const Color(0xFF1565C0),
                              fontWeight: FontWeight.bold,
                            ),
                            onSelected: (selected) {
                              if (selected) _fillAdminCredentials();
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      TextField(
                        controller: _emailController,
                        decoration: InputDecoration(
                          labelText: 'Email',
                          prefixIcon: const Icon(Icons.email_outlined, color: Color(0xFF1565C0)),
                          filled: true,
                          fillColor: const Color(0xFFF5F9FF),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: Color(0xFF1565C0), width: 1.5),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _passwordController,
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: 'Password',
                          prefixIcon: const Icon(Icons.lock_outline, color: Color(0xFF1565C0)),
                          filled: true,
                          fillColor: const Color(0xFFF5F9FF),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(color: Color(0xFF1565C0), width: 1.5),
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1565C0),
                            foregroundColor: Colors.white,
                            elevation: 3,
                            shadowColor: const Color(0x661565C0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          onPressed: _login,
                          child: Text(
                            _selectedRole == 'Admin' ? 'Login as Admin' : 'Login as Student',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
