import 'package:flutter/material.dart';
import 'app_data.dart';

class AdminDashboardPage extends StatefulWidget {
  const AdminDashboardPage({super.key});

  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  final AppData _appData = AppData();
  int _adminTab = 0;

  void _addNewCourseDialog() {
    final codeController = TextEditingController();
    final titleController = TextEditingController();
    final instructorController = TextEditingController();
    final creditController = TextEditingController(text: '3 Cr. Hrs');

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Row(
            children: [
              Icon(Icons.add_circle_outline, color: Color(0xFF1565C0)),
              SizedBox(width: 10),
              Text('Add New Global Course'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: codeController,
                  decoration: const InputDecoration(labelText: 'Course Code (e.g. CS-501)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(labelText: 'Course Title', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: instructorController,
                  decoration: const InputDecoration(labelText: 'Instructor Name', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: creditController,
                  decoration: const InputDecoration(labelText: 'Credit Hours', border: OutlineInputBorder()),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white),
              onPressed: () {
                if (codeController.text.isNotEmpty && titleController.text.isNotEmpty) {
                  setState(() {
                    _appData.addGlobalCourse(
                      codeController.text.trim(),
                      titleController.text.trim(),
                      instructorController.text.trim(),
                      creditController.text.trim(),
                    );
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Course "${titleController.text}" added to catalog.'),
                      backgroundColor: const Color(0xFF2E7D32),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
              child: const Text('Add Course'),
            ),
          ],
        );
      },
    );
  }

  void _addNewStudentDialog() {
    final nameController = TextEditingController();
    final emailController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Row(
            children: [
              Icon(Icons.person_add_rounded, color: Color(0xFF1565C0)),
              SizedBox(width: 10),
              Text('Add New Student'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Student Name', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: emailController,
                  decoration: const InputDecoration(labelText: 'Email Address', border: OutlineInputBorder()),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white),
              onPressed: () {
                if (nameController.text.isNotEmpty && emailController.text.isNotEmpty) {
                  setState(() {
                    _appData.addStudent(nameController.text.trim(), emailController.text.trim());
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Student "${nameController.text}" added successfully!'),
                      backgroundColor: const Color(0xFF2E7D32),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              },
              child: const Text('Add Student'),
            ),
          ],
        );
      },
    );
  }

  void _deleteCourse(CourseItem course) {
    setState(() {
      _appData.removeGlobalCourse(course.code);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Deleted course "${course.title}"'),
        backgroundColor: Colors.red.shade700,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    int totalPendingRequests = 0;
    for (var s in _appData.students) {
      totalPendingRequests += s.pendingCourses.length;
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FA),
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0D47A1), Color(0xFF1565C0)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _adminTab,
        onDestinationSelected: (index) {
          setState(() {
            _adminTab = index;
          });
        },
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.menu_book_rounded),
            label: 'Manage Courses',
          ),
          const NavigationDestination(
            icon: Icon(Icons.people_alt_rounded),
            label: 'Manage Students',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: totalPendingRequests > 0,
              label: Text('$totalPendingRequests'),
              child: const Icon(Icons.approval_rounded),
            ),
            label: 'Approvals',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_adminTab == 0) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Global Course Catalog',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF0D47A1)),
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white),
                    onPressed: _addNewCourseDialog,
                    icon: const Icon(Icons.add, size: 18),
                    label: const Text('Add Course'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _appData.globalCourses.length,
                itemBuilder: (context, index) {
                  final course = _appData.globalCourses[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 2,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    color: Colors.white,
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      title: Text(
                        course.title,
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0D47A1)),
                      ),
                      subtitle: Text('${course.code} • ${course.instructor} • ${course.creditHours}'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                        onPressed: () => _deleteCourse(course),
                      ),
                    ),
                  );
                },
              ),
            ] else if (_adminTab == 1) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Registered Students',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF0D47A1)),
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1565C0), foregroundColor: Colors.white),
                    onPressed: _addNewStudentDialog,
                    icon: const Icon(Icons.person_add, size: 18),
                    label: const Text('Add Student'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _appData.students.length,
                itemBuilder: (context, index) {
                  final student = _appData.students[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    elevation: 3,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const CircleAvatar(
                                backgroundColor: Color(0xFFE3F2FD),
                                child: Icon(Icons.person, color: Color(0xFF1565C0)),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      student.name,
                                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0D47A1)),
                                    ),
                                    Text(
                                      student.email,
                                      style: const TextStyle(fontSize: 13, color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 24),
                          Text(
                            'Enrolled Courses (${student.registeredCourses.length}):',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF37474F)),
                          ),
                          const SizedBox(height: 8),
                          student.registeredCourses.isEmpty
                              ? const Text('No courses enrolled.', style: TextStyle(color: Colors.grey, fontSize: 13))
                              : Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: student.registeredCourses.map((c) {
                                    return Chip(
                                      label: Text(c.code),
                                      deleteIcon: const Icon(Icons.close, size: 16),
                                      onDeleted: () {
                                        setState(() {
                                          _appData.dropCourseForStudent(student, c);
                                        });
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            content: Text('Dropped "${c.title}" from ${student.name}'),
                                            backgroundColor: Colors.red.shade700,
                                            behavior: SnackBarBehavior.floating,
                                          ),
                                        );
                                      },
                                    );
                                  }).toList(),
                                ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ] else ...[
              const Text(
                'Student Registration Approvals',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF0D47A1)),
              ),
              const SizedBox(height: 6),
              const Text(
                'Approve or reject course registration requests from students.',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
              const SizedBox(height: 16),
              totalPendingRequests == 0
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(40.0),
                        child: Text(
                          'No pending registration requests.',
                          style: TextStyle(color: Colors.grey, fontSize: 16),
                        ),
                      ),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _appData.students.length,
                      itemBuilder: (context, studentIndex) {
                        final student = _appData.students[studentIndex];
                        if (student.pendingCourses.isEmpty) return const SizedBox.shrink();

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8.0),
                              child: Text(
                                'Student: ${student.name} (${student.email})',
                                style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1565C0)),
                              ),
                            ),
                            ...student.pendingCourses.map((course) {
                              return Card(
                                margin: const EdgeInsets.only(bottom: 10),
                                elevation: 2,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                child: ListTile(
                                  title: Text(course.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                                  subtitle: Text('${course.code} • ${course.instructor}'),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.check_circle_rounded, color: Colors.green, size: 28),
                                        onPressed: () {
                                          setState(() {
                                            _appData.approveCourse(student, course);
                                          });
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: Text('Approved "${course.title}" for ${student.name}'),
                                              backgroundColor: const Color(0xFF2E7D32),
                                              behavior: SnackBarBehavior.floating,
                                            ),
                                          );
                                        },
                                        tooltip: 'Approve',
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.cancel_rounded, color: Colors.redAccent, size: 28),
                                        onPressed: () {
                                          setState(() {
                                            _appData.rejectCourse(student, course);
                                          });
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: Text('Rejected "${course.title}" for ${student.name}'),
                                              backgroundColor: Colors.red.shade700,
                                              behavior: SnackBarBehavior.floating,
                                            ),
                                          );
                                        },
                                        tooltip: 'Reject',
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }),
                          ],
                        );
                      },
                    ),
            ],
          ],
        ),
      ),
    );
  }
}
